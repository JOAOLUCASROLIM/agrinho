function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let isCity = false;
let birds = [];  // Armazenar pássaros no campo
let cars = [];   // Armazenar carros na cidade
let people = []; // Armazenar pessoas na cidade
let clouds = []; // Armazenar nuvens

function setup() {
  createCanvas(800, 600);
  // Adiciona um botão para alternar entre cidade e campo
  let button = createButton('Alternar');
  button.position(10, 10);
  button.mousePressed(toggleScene);
  
  // Criar objetos aleatórios (pássaros, carros, nuvens, pessoas)
  for (let i = 0; i < 5; i++) {
    birds.push(new Bird(random(50, 750), random(50, 200)));
  }
  for (let i = 0; i < 3; i++) {
    cars.push(new Car(random(100, 700), random(400, 500)));
  }
  for (let i = 0; i < 4; i++) {
    people.push(new Person(random(100, 700), random(300, 450)));
  }
  for (let i = 0; i < 3; i++) {
    clouds.push(new Cloud(random(50, 750), random(50, 200)));
  }
}

function draw() {
  if (isCity) {
    drawCity();
  } else {
    drawField();
  }

  // Atualizar objetos que se movem (pássaros, carros, pessoas, nuvens)
  updateMovingObjects();
}

// Função que desenha o campo
function drawField() {
  background(135, 206, 235); // Cor do céu
  fill(34, 139, 34); // Cor do campo
  rect(0, height / 2, width, height / 2); // Desenha o campo
  
  // Nuvens no céu
  for (let cloud of clouds) {
    cloud.move();
    cloud.display();
  }
  
  // Árvores
  drawTree(100, height / 2 + 50);
  drawTree(300, height / 2 + 70);
  drawTree(500, height / 2 + 40);
  
  // Sol
  fill(255, 223, 0);
  ellipse(500, 100, 80, 80);
  
  // Pássaros voando
  for (let bird of birds) {
    bird.move();
    bird.display();
  }
}

// Função que desenha a cidade
function drawCity() {
  background(169, 169, 169); // Cor do céu da cidade
  
  // Edifícios
  drawBuilding(50, 200, 100, 200);
  drawBuilding(200, 150, 80, 250);
  drawBuilding(350, 180, 120, 220);
  drawBuilding(500, 170, 90, 240);
  
  // Rua
  fill(50, 50, 50);
  rect(0, height / 2, width, height / 2); // Rua
  
  // Carros se movendo
  for (let car of cars) {
    car.move();
    car.display();
  }
  
  // Pessoas andando
  for (let person of people) {
    person.move();
    person.display();
  }
  
  // Luzes da cidade (prédios iluminados)
  drawCityLights(50, 180);
  drawCityLights(200, 120);
  drawCityLights(350, 160);
}

// Funções auxiliares (Desenho de elementos)
function drawTree(x, y) {
  fill(139, 69, 19); // Tronco da árvore
  rect(x - 10, y, 20, 40); // Tronco
  fill(34, 139, 34); // Folhagem
  ellipse(x, y - 20, 60, 60); // Folhas
}

function drawBuilding(x, y, w, h) {
  fill(105, 105, 105); // Cor do prédio
  rect(x, y, w, h); // Corpo do prédio
}

function drawCityLights(x, y) {
  fill(255, 255, 0); // Cor das luzes
  ellipse(x + 20, y + 20, 8, 8); // Luzes no prédio
}

// Função para alternar entre cidade e campo
function toggleScene() {
  isCity = !isCity;
}

// Objetos em movimento

class Bird {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 15;
    this.speed = random(1, 3);
  }
  
  move() {
    this.x += this.speed;
    if (this.x > width) this.x = 0; // Se o pássaro sair da tela, ele reaparece
  }
  
  display() {
    fill(0);
    ellipse(this.x, this.y, this.size, this.size); // Corpo
    line(this.x - 5, this.y, this.x - 15, this.y - 10); // Asa esquerda
    line(this.x + 5, this.y, this.x + 15, this.y - 10); // Asa direita
  }
}

class Car {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.width = 40;
    this.height = 20;
    this.speed = random(1, 3);
  }
  
  move() {
    this.x += this.speed;
    if (this.x > width) this.x = -this.width; // Se o carro sair da tela, ele reaparece
  }
  
  display() {
    fill(255, 0, 0);
    rect(this.x, this.y, this.width, this.height); // Corpo do carro
    fill(0);
    ellipse(this.x + 10, this.y + this.height, 15, 15); // Roda 1
    ellipse(this.x + 30, this.y + this.height, 15, 15); // Roda 2
  }
}

class Person {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 20;
    this.speed = random(0.5, 2);
  }
  
  move() {
    this.x += this.speed;
    if (this.x > width) this.x = -this.size; // Se a pessoa sair da tela, ela reaparece
  }
  
  display() {
    fill(255, 224, 189); // Corpo da pessoa
    ellipse(this.x, this.y, this.size, this.size); // Cabeça
    line(this.x, this.y + 10, this.x, this.y + 30); // Corpo
    line(this.x, this.y + 30, this.x - 10, this.y + 50); // Perna esquerda
    line(this.x, this.y + 30, this.x + 10, this.y + 50); // Perna direita
  }
}

class Cloud {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 60;
    this.speed = random(0.5, 1);
  }
  
  move() {
    this.x += this.speed;
    if (this.x > width) this.x = -this.size; // Se a nuvem sair da tela, ela reaparece
  }
  
  display() {
    fill(255, 255, 255, 180);
    ellipse(this.x, this.y, this.size, this.size); // Nuvem
  }
}

function updateMovingObjects() {
  // Atualiza o movimento de todos os objetos (pássaros, carros, pessoas, nuvens)
  for (let bird of birds) bird.move();
  for (let car of cars) car.move();
  for (let person of people) person.move();
  for (let cloud of clouds) cloud.move();
}
